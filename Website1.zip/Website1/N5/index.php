<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		
		
		<title>Website Informático / PAP</title>
		
		
		<!--=====================================================
			CSS Stylesheets
		=====================================================-->
		<link rel='stylesheet' type='text/css' href='bootstrap/css/bootstrap.min.css' >
		<link rel='stylesheet' type='text/css' href='css/linea.css' >
		<link rel='stylesheet' type='text/css' href='css/ionicons.min.css' >
		<link rel='stylesheet' type='text/css' href='css/owl.carousel.css' >
		<link rel='stylesheet' type='text/css' href='css/magnific-popup.css' >
		<link rel='stylesheet' type='text/css' href='css/style.css' >
		<link rel="stylesheet" type="text/css" href="css/style1.css" />
																							
	</head>
	<body>
		
		
		<!--=====================================================
			Preloader
		=====================================================-->
		<div id='preloader' >
			<div class='loader' ></div>
			<div class='left' ></div>
			<div class='right' ></div>
		</div>
		
		<div class='main-content' >
		
			<!--=====================================================
				Page Borders
			=====================================================-->
			<div class='page-border border-left' ></div>
			<div class='page-border border-right' ></div>
			<div class='page-border border-top' ></div>
			<div class='page-border border-bottom' ></div>
			
			
			
			<!--=====================================================
				Menu Button
			=====================================================-->
			<a href='#' class='menu-btn' >
				<span class='lines' >
					<span class='l1' ></span>
					<span class='l2' ></span>
					<span class='l3' ></span>
				</span>
			</a>
			
			
			<!--=====================================================
				Menu
			=====================================================-->
			<div class='menu' >
				<div class='inner' >
					<ul class='menu-items' >
						
						<li>
							<a href='#' class='section-toggle' data-section='intro' >
								Início
							</a>
						</li>
						
						<li>
							<a href='#about' class='section-toggle' data-section='about' >
								Documentação
							</a>
						</li>
						
						<li>
							<a href='#resume' class='section-toggle' data-section='resume' >
								Alunos ST EPT
							</a>
						</li>
						
						<li>
							<a href='#portfolio' class='section-toggle' data-section='portfolio' >
								Tondela
							</a>
						</li>
						
						
						<li>
							<a href='#contact' class='section-toggle' data-section='contact' >
								Contacto
							</a>
						</li>
						
						
					</ul>
				</div>
			</div>
			
			<div class='animation-block' ></div>
			
			
			<!--=====================================================
				Sections
			=====================================================-->
			<div class='sections' >
				
				<!--=====================================================
					Main Section
				=====================================================-->
				<section id='intro' class='section section-main active' >
					
					<div class='container-fluid' >
						
						<div class='v-align' >
							<div class='inner' >
								<div class='intro-text' >
									
									<h1>Bem-Vindo ao InforStp</h1>
									
									<p>
										InforStp é um web site desenvolvido para ajudar os alunos Santomenses, com interesse em estudar na Escola Profissional de Tondela.
									</p>
									
									<div class='intro-btns' >
										
										<a href='#about' class='btn-custom section-toggle' data-section='about' >
											Documentação
										</a>
										
										<a href='#contact' class='btn-custom section-toggle' data-section='contact' >
											Contacte Nos
										</a>
										
									</div>
									
								</div>
							</div>
							
						</div>
						
					</div>
				
				</section>
				
				
				<!--=====================================================
					About Section
				=====================================================-->
				<section id='about' class='section about-section border-d' >
					
					<div class='section-block about-block' >
						<div class='container-fluid' >
							
							<div class='section-header' >
								<h2>
									Sou <strong class='color' >Aluno</strong>
								</h2>
							</div>
							
							<div class='row' >
								
								<div class='col-md-4' >
									
									<ul class='info-list' >
										
										<li>
											<strong>Nome:</strong>
											<span>Stéfano Costa</span>
										</li>
										
										<li>
											<strong>Nacionalidade:</strong>
											<span>Santomense</span>
										</li>
										
										<li>
											<strong>Idade:</strong>
											<span>20 anos</span>
										</li>
										
										<li>
											<strong>País residente:</strong>
											<span>Portugal</span>
										</li>
										
										<li>
											<strong>Cidade:</strong>
											<span>Tondela</span>
										</li>
										
										
										
									</ul>
									
								</div>
								
								<div class='col-md-8' >
								
									<div class='about-text' >
										<p>
											Nasci e fui criado em São Tomé e Príncipe, e sempre morei com os meus pais e dois irmãos. Aos 17, mudei-me para Portugal a fim de estudar e agora moro com colegas em um apartamento próximo a escola.
										</p>
										
										<p>
											Estudo Informática de Gestão na Escola Profissional de Tondela,no terceiro ano do curso. Pretendo seguir a area de gestão no mercado de trabalho. Sempre tive muito apoio dos meus pais para seguir está area. Eles acreditam que o conhecimento que o conhecimento é a única coisa que ninguém pode tirar de nós e que a a educação é a melhor herança que podem deixar pra mim e meus irmãos. Tenho muita disposição em aprender e conhecer coisas novas. Gosto de trabalhar em grupo e interagir com outras pessoas. Acho, também, que o contata pessoal no ambiente de trabalho ou de estudos é fundamental. O Website permitirá de forma simples e rápida a troca de informações entre alunos santomenses.
										</p>
										
									</div>
									
									<div class='about-btns' >
										
										
										
									</div>
									
								</div>
								
							</div>
							
						</div>
					</div>
					
					
					
				</section>
				
				
				<!--=====================================================
					Resume Section
				=====================================================-->
				<section id='resume' class='section resume-section border-d' >
					
					<div class='section-block timeline-block' >
						
						<div class='container-fluid' >
							
							<div class='section-header' >
								
								<h2>Alunos <strong class='color' >Santomenses</strong></h2>
								
							</div>
							
							<ul class='portfolio-items' >
							<?php
	
	/*-- we included connection files--*/
	include "con.php";

	$result = mysqli_connect($host,$uname,$pwd) or die("Could not connect to database." .mysqli_error());
	mysqli_select_db($result,$db_name) or die("Could not select the databse." .mysqli_error());
	$image_query = mysqli_query($result,"select id, nome, img_path, descricao from port");
	while($rows = mysqli_fetch_array($image_query))
	{
		$id = $rows['id'];
		$img_name = $rows['nome'];
        $descricao = $rows['descricao'];
		$img_src = $rows['img_path'];
	?>
								<li data-groups='["port1"]' >
									
									<div class='inner' >
	
										<img src='admin/examples/user/<?php echo $img_src; ?>' alt="" width="400" height="300">
										
										<div class='overlay' >
											
											<a href='#popup-<?php echo $id; ?>' class='view-project' >
												Ver Aluno
											</a>
											
											<!--project popup-->
											<div id='popup-<?php echo $id; ?>' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='admin/examples/user/<?php echo $img_src; ?>' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4><?php echo $img_name; ?></h4>
													
													<!--project popup description-->
													<p>
													<?php echo $descricao; ?>
													</p>
													
												</div>

											</div>
											
										</div>
										
									</div>
				
								</li>
								<?php
                    }
?>
							</ul>
							
						</div>
					</div>
					
				</section>
				
				
				<!--=====================================================
					Portfolio Section
				=====================================================-->
				<section id='portfolio' class='section portfolio-section border-d' >
					
					<div class='section-block portfolio-block' >
						
						<div class='container-fluid' >
							
							
							<div class='section-header' >
								<h2>Edifícios <strong class='color' >Tondela</strong></h2>
							</div>
							
							
							<ul class='portfolio-items' >
								
								<li data-groups='["Segurança Social"]' >
									<div class='inner' >
										<img src='img/portfolio/7.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-1' class='view-project' >
												Segurança Social
											</a>
											
											<!--project popup-->
											<div id='popup-1' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/7.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Segurança Social</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Rua Tomás Ribeiro, lote 6, r/c
3460-616 Tondela
Telefone: 964 340 598

													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["Finanças"]' >
									<div class='inner' >
										<img src='img/portfolio/8.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-2' class='view-project' >
												Serviço de Finanças
											</a>
											
											<!--project popup-->
											<div id='popup-2' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/8.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Serviço de Finanças</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Praceta, R. Dr. Teofilo da Cruz, 3460-551 Tondela
														Telefone: 932 645 286
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["GNR"]' >
									<div class='inner' >
										<img src='img/portfolio/9.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-3' class='view-project' >
												GNR
											</a>
											
											<!--project popup-->
											<div id='popup-3' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/9.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>GNR</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Rua. Pedro de Figueiredo 3460-608, Tondela
														   Telefone: 232 819 370
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								
								<li data-groups='["Hospital"]' >
									<div class='inner' >
										<img src='img/portfolio/10.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-4' class='view-project' >
												Hospital Cândido de Figueiredo
											</a>
											
											<!--project popup-->
											<div id='popup-4' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/10.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Hospital Cândido de Figueiredo</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Av. General Humberto Delgado, 3460-525 Tondela
														Telefone: 232 819 060
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["Bombeiros"]' >
									<div class='inner' >
										<img src='img/portfolio/144.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-5' class='view-project' >
												Bombeiros Voluntários
											</a>
											
											<!--project popup-->
											<div id='popup-5' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/144.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Bombeiros Voluntários</h4>
													
													<!--project popup description-->
													<p>
														Endereço: R. Bombeiros Voluntários Nº12, 3460-572 Tondela
														Telefone: 232 814 110
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["Câmara"]' >
									<div class='inner' >
										<img src='img/portfolio/12.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-6' class='view-project' >
												Câmara Municipal
											</a>
											
											<!--project popup-->
											<div id='popup-6' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/12.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Câmara Municipal</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Largo República N.º 16, 3460-001 Tondela
														Telefone: 232 811 110
														Email: geral@cm-tondela.pt
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["Tribunal"]' >
									<div class='inner' >
										<img src='img/portfolio/11.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-7' class='view-project' >
												Tribunal
											</a>
											
											<!--project popup-->
											<div id='popup-7' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/11.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Tribunal</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Largo Prof. Dr. Anselmo Ferraz de Carvalho 200, Tondela
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
								<li data-groups='["Museu"]' >
									<div class='inner' >
										<img src='img/portfolio/13.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-8' class='view-project' >
												Museu
											</a>
											
											<!--project popup-->
											<div id='popup-8' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/13.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Museu</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Solar de Santa Ana, R. Dr. Simões de Carvalho, 3460-588 Tondela
														Telefone: 232 823 400
													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								<li data-groups='["Igreja"]' >
									<div class='inner' >
										<img src='img/portfolio/14.jpg' alt>
										
										<div class='overlay' >
											
											<a href='#popup-9' class='view-project' >
												Igreja Paroquial
											</a>
											
											<!--project popup-->
											<div id='popup-9' class='popup-box zoom-anim-dialog mfp-hide' >
												<figure>
													
													<!--project popup image-->
													<img src='img/portfolio/14.jpg' alt>
												
												</figure>
												<div class='content' >
													
													<!--project popup title-->
													<h4>Igreja Paroquial</h4>
													
													<!--project popup description-->
													<p>
														Endereço: Largo Prof. Dr. Anselmo Ferraz de Carvalho 145, 3460-534 Tondela
														Telefone: 232 822 240

													</p>
													
												</div>
												
											</div>
											
										</div>
										
									</div>
								</li>
								
							</ul>
							
						</div>
					
					</div>
					
				</section>
				
				
				<!--=====================================================
					Contact Section
				=====================================================-->
				<section id='contact' class='section contact-section border-d' >
					
					<div class='section-block contact-block' >
						
						<div class='container-fluid' >
							
							<div class='section-header' >
								<h2>Contacte <strong class='color' >Nos</strong></h2>
							</div>
							
							
							<div class='row' >
							
								<div class='col-md-8' >
									
									<div class='contact-form' >
									
										<form method='post' action='http://localhost:8888/PAP/website1/N5/process.php' >
										
											<div class='row' >
												
												<div class='col-md-6' >
													<div class='form-group' >
														
														<input type='text' class='form-control' placeholder='Nome' name='nome' required>
														
													</div>												
												</div>
												
												<div class='col-md-6' >
													<div class='form-group' >
														
														<input type='email' class='form-control' placeholder='Email' name='email' required>
													
													</div>
												</div>
												
											</div>
											
											<div class='form-group' >
												
												<input type='text' class='form-control' placeholder='Assunto' name='assunto' required>
											
											</div>
											
											<div class='form-group' >
												
												<textarea class='form-control' placeholder='Mensagem' name='mensagem' rows='5' required></textarea>
												
											</div>
											
											<div class='form-group text-center' >
												<button type='submit' class='btn-custom btn-color' >
													Enviar Mensagem
												</button>
											</div>
											
										</form>
										
									</div>
									
									
								</div>
								
								<div class='col-md-4' >
									
									<div class='contact-info-icons' >
										
										<div class='contact-info' >
											
											<i class='ion-ios-location-outline' ></i>
											
											<p>
												Rua Visconde de Tondela<br>
												3460-526, Tondela
											</p>
											
										</div>
										
										
										<div class='contact-info' >
											
											<i class='ion-ios-telephone-outline' ></i>
											
											<p>
												(+351) 927 460 992<br>
												(+351) 912 962 385
											</p>
											
										</div>
										
										
										<div class='contact-info' >
											
											<i class='ion-android-globe' ></i>
											
											<p>
												www.google.com<br>
												www.example.com
											</p>
											
										</div>
										
										
										
										
									</div>
									
									
									
								</div>
								
								
							</div>
							
							
							
						</div>
					
					</div>
					
				</section>
				
			</div>
			
		</div>
		
		
		<!--=====================================================
			JavaScript Files
		=====================================================-->
		<script src='js/jquery.min.js' ></script>
		<script src='js/jquery.shuffle.min.js' ></script>
		<script src='js/owl.carousel.min.js' ></script>
		<script src='js/jquery.magnific-popup.min.js' ></script>
		<script src='js/validator.min.js' ></script>
		<script src='js/script.js' ></script>
		
	</body>
</html>