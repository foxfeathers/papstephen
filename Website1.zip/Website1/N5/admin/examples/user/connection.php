<?php

	$host ="localhost";
	$uname = "joao";
	$pwd = '123';
	$db_name = "Inforstp";

        ?>
	