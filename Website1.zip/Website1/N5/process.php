<?php

include("conexao.php");
extract($_POST);
$sql = "INSERT INTO `contacto`(`nome`, `email`, `assunto`, `mensagem`) VALUES ('".$nome."','".$email."','".$assunto."','".$mensagem."')";
$result = $mysqli->query($sql);
if(!$result){
    die("Couldn't enter data: ".$mysqli->error);
}

echo '<script> alert ("Thank You For Contacting Us ")</script>';


$mysqli->close();
?>

