<?php
define("DB_HOST","localhost");
define("DB_USER","");
define("DB_PASSWORD","");
define("DB_NAME","Inforstp");
$mysqli = new mysqli(DB_HOST,DB_USER, DB_PASSWORD,DB_NAME);
?>